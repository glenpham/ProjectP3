package com.project.web.service;

import com.project.web.model.Application;
import com.project.web.repository.AdoptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdoptionService {

    @Autowired
    private AdoptionRepository adoptionRepository;

    public void saveApplicationToDB(String fname, String lname, String email, String address, String phone) {
        Application application = new Application();

        application.setFname(fname);
        application.setLname(lname);
        application.setEmail(email);
        application.setAddress(address);
        application.setPhoneNum(phone);
        adoptionRepository.save(application);
    }

    public List<Application> getAllApplications() {
        return adoptionRepository.findAll();
    }

    public void deleteAdoptionById(Long id) {
        adoptionRepository.deleteById(id);
    }

}
