package com.project.web.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.*;

@Entity
@Getter
@Setter
@Table(name = "pets")
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class Pet {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@NotNull
	private String type;

	@NotNull
	private String gender;

	@NotNull
	private String breed;

	@NotNull
	private int age;

	@NotNull
	private String name;

	@NotNull
	private int price;

	@Lob
	@Column(columnDefinition = "MEDIUMBLOB")
	private String image;

	@NotNull
	@Size(max = 250)
	private String description;
}