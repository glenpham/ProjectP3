package com.project.web.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.*;

@AllArgsConstructor
@Builder
@NoArgsConstructor
@Getter
@Setter
public class Address {

    private int id;

    private int doorNum;

    private String street;

    private String city;

    private String state;

    private String country;
}
