package com.project.web.model;

import lombok.*;

import javax.persistence.*;

@Entity
@Getter
@Setter
@Table(name = "applications")
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class Application {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "application_id")
    private Long id;

    private String fname;

    private String lname;

    private String email;

    private String address;

    private String phoneNum;
}
