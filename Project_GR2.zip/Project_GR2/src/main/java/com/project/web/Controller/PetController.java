package com.project.web.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.project.web.model.Pet;
import com.project.web.service.PetService;

@Controller
public class PetController {

    @Autowired
    private PetService petService;

    @GetMapping("/listPets")
    public String showExampleView(Model model) {
        List<Pet> pets = petService.getAllPets();
        model.addAttribute("pets", pets);
        return "/listPets";
    }

    @GetMapping("/")
    public String showAddPet() {
        return "/addPet";
    }

    @PostMapping("/addPet")
    public String savePet(@RequestParam("file") MultipartFile file,
                          @RequestParam("type") String type,
                          @RequestParam("gender") String gender,
                          @RequestParam("breed") String breed,
                          @RequestParam("age") int age,
                          @RequestParam("name") String name,
                          @RequestParam("price") int price,
                          @RequestParam("desc") String desc) {
        petService.savePetToDB(file, type, gender, breed, age, name, price, desc);
        return "redirect:/listPets";
    }

    @GetMapping("/deletePet/{id}")
    public String deletePet(@PathVariable("id") Long id) {
        petService.deletePetById(id);
        return "redirect:/listPets";
    }

    @PostMapping("/changeName")
    public String changeName(@RequestParam("id") Long id,
                              @RequestParam("newName") String name) {
        petService.changePetName(id, name);
        return "redirect:/listPets";
    }

    public String changeAge(@RequestParam("id") Long id,
                          @RequestParam("newAge") int age) {
        petService.changePetAge(id, age);
        return "redirect:/listPets";
    }

    @PostMapping("/changeDescription")
    public String changeDescription(@RequestParam("id") Long id,
                                    @RequestParam("newDescription") String description) {
        petService.changePetDescription(id, description);
        return "redirect:/listPets";
    }

    @PostMapping("/changePrice")
    public String changePrice(@RequestParam("id") Long id,
                              @RequestParam("newPrice") int price) {
        petService.changePetPrice(id, price);
        return "redirect:/listPets";
    }
}