package com.project.web.Controller;

import com.project.web.model.Application;
import com.project.web.service.AdoptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class ApplicationController {

    @Autowired
    private AdoptionService adoptionService ;

    @GetMapping("/applications")
    public String showExampleView(Model model) {
        List<Application> applicationList = adoptionService.getAllApplications();
        model.addAttribute("applications", applicationList);
        return "/listApplications";
    }

    @GetMapping("/adoptionForm")
    public String showAdoptionForm() {
        return "/addApplication";
    }

    @PostMapping("/addAdoption")
    public String savePet(@RequestParam("fname") String fname,
                          @RequestParam("lname") String lname,
                          @RequestParam("email") String email,
                          @RequestParam("address") String address,
                          @RequestParam("phone") String phone) {
        adoptionService.saveApplicationToDB(fname, lname, email, address, phone);
        return "redirect:/applications";
    }

    @GetMapping("/deleteApplication/{id}")
    public String deleteApplication(@PathVariable("id") Long id) {
        adoptionService.deleteAdoptionById(id);
        return "redirect:/applications";
    }
}
