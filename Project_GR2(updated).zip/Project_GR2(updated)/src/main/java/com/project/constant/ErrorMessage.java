package com.project.constant;

public class ErrorMessage {
    public static final String NAME_IS_REQUIRED_ERROR_MESSAGE = "please provide name";
    public static final String NAME_SIZE_ERROR_MESSAGE = "The name needs to be at least 2 character";
    public static final String EMAIL_IS_REQUIRED_ERROR_MESSAGE = "please provide email";
    public static final String ADDRESS_IS_REQUIRED_ERROR_MESSAGE = "please provide address";
    public static final String PHONE_IS_REQUIRED_ERROR_MESSAGE = "please provide phone number";
    public static final String PHONE_SIZE_ERROR_MESSAGE = "Phone number must be 10 digits or more";
}