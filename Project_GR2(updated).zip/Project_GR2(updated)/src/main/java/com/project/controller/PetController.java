package com.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.project.model.Pet;
import com.project.service.PetService;

import javax.validation.Valid;

@Controller
public class PetController {

    @Autowired
    private PetService petService;

    @GetMapping("/")
    public String showPetList(Model model) {
        List<Pet> pets = petService.getAllPets();
        model.addAttribute("pets", pets);
        return "listPets";
    }

    @GetMapping("/addNew")
    public String addNewPet() {
        return "addPet";
    }

    @PostMapping("/savePet")
    public String savePet(@RequestParam("file") MultipartFile file,
                          @RequestParam("type") String type,
                          @RequestParam("gender") String gender,
                          @RequestParam("breed") String breed,
                          @RequestParam("age") int age,
                          @RequestParam("name") String name,
                          @RequestParam("price") int price,
                          @RequestParam("desc") String desc) {

        petService.savePetToDB(file, type, gender, breed, age, name, price, desc);
        return "redirect:/";
    }

    @GetMapping("/deletePet/{id}")
    public String deletePet(@PathVariable("id") Long id) {
        petService.deletePetById(id);
        return "redirect:/";
    }

    @PostMapping("/changeName")
    public String changeName(@RequestParam("id") Long id,
                              @RequestParam("newName") String name) {
        petService.changePetName(id, name);
        return "redirect:/";
    }

    @PostMapping("/changeBreed")
    public String changeBreed(@RequestParam("id") Long id,
                             @RequestParam("newBreed") String breed) {
        petService.changePetBreed(id, breed);
        return "redirect:/";
    }

    @PostMapping("/changeGender")
    public String changeGender(@RequestParam("id") Long id,
                              @RequestParam("newGender") String gender) {
        petService.changePetGender(id, gender);
        return "redirect:/";
    }

    @PostMapping("/changeAge")
    public String changeAge(@RequestParam("id") Long id,
                          @RequestParam("newAge") int age) {
        petService.changePetAge(id, age);
        return "redirect:/";
    }

    @PostMapping("/changeDescription")
    public String changeDescription(@RequestParam("id") Long id,
                                    @RequestParam("newDescription") String description) {
        petService.changePetDescription(id, description);
        return "redirect:/";
    }

    @PostMapping("/changePrice")
    public String changePrice(@RequestParam("id") Long id,
                              @RequestParam("newPrice") int price) {
        petService.changePetPrice(id, price);
        return "redirect:/";
    }
}