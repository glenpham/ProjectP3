package com.project.controller;

import java.util.List;

import com.project.dto.PetInput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.project.model.Pet;
import com.project.service.PetService;

import javax.validation.Valid;

@Controller
public class PetController {

    @Autowired
    private PetService petService;

    @GetMapping("/")
    public String showPetList(Model model) {
        List<Pet> pets = petService.getAllPets();
        model.addAttribute("pets", pets);
        return "listPets";
    }

    @GetMapping("/admin")
    public String showAdminPetList(Model model) {
        List<Pet> pets = petService.getAllPets();
        model.addAttribute("pets", pets);
        return "adminPets";
    }

    @GetMapping("/addNew")
    public String savePet(Model model) {
        PetInput pet = new PetInput();
        model.addAttribute("pet", pet);
        return "addPet";
    }

    @PostMapping("/save")
    public String savePet(@Valid @ModelAttribute("pet") PetInput savePet, BindingResult result){

        if (result.hasErrors()){
            //I need to stay in the current page !!!!
            return "addPet";
        }

        petService.savePetToDB(savePet);
        return "redirect:/admin";
    }

    @GetMapping("/deletePet/{id}")
    public String deletePet(@PathVariable("id") Long id) {
        petService.deletePetById(id);
        return "redirect:/admin";
    }

    @PostMapping("/changeName")
    public String changeName(@RequestParam("id") Long id,
                              @RequestParam("newName") String name) {
        petService.changePetName(id, name);
        return "redirect:/";
    }

    @PostMapping("/changeBreed")
    public String changeBreed(@RequestParam("id") Long id,
                             @RequestParam("newBreed") String breed) {
        petService.changePetBreed(id, breed);
        return "redirect:/";
    }

    @PostMapping("/changeGender")
    public String changeGender(@RequestParam("id") Long id,
                              @RequestParam("newGender") String gender) {
        petService.changePetGender(id, gender);
        return "redirect:/";
    }

    @PostMapping("/changeAge")
    public String changeAge(@RequestParam("id") Long id,
                          @RequestParam("newAge") int age) {
        petService.changePetAge(id, age);
        return "redirect:/";
    }

    @PostMapping("/changeDescription")
    public String changeDescription(@RequestParam("id") Long id,
                                    @RequestParam("newDescription") String description) {
        petService.changePetDescription(id, description);
        return "redirect:/";
    }

    @PostMapping("/changePrice")
    public String changePrice(@RequestParam("id") Long id,
                              @RequestParam("newPrice") int price) {
        petService.changePetPrice(id, price);
        return "redirect:/";
    }
}