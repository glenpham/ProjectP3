package com.project.controller;

import com.project.model.Application;
import com.project.model.Pet;
import com.project.service.AdoptionService;
import com.project.service.PetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Controller
public class ApplicationController {

    @Autowired
    private AdoptionService adoptionService ;

    @Autowired
    private PetService petService;

    @GetMapping("/applications")
    public String showApplications(Model model) {
        List<Application> applicationList = adoptionService.getAllApplications();
        model.addAttribute("applications", applicationList);
        return "/listApplications";
    }

    @GetMapping("/adoptionForm/{id}")
    public String showAdoptionForm(@PathVariable Long id, Model model) {
        Application application = new Application();
        Long currentPetId = petService.getPetById(id).get().getId();
        application.setPetID(currentPetId);
        model.addAttribute("application", application);
        return "addApplication";
    }

    @PostMapping("/addAdoption")
    public String saveApplication(@Valid @ModelAttribute("application") Application saveApplication, BindingResult result) {

        if (result.hasErrors()){
            //I need to stay in the current page !!!!
            return "addApplication";
        }
        adoptionService.saveApplicationToDB(saveApplication);
        return "redirect:/applications";
    }

    @GetMapping("/deleteApplication/{id}")
    public String deleteApplication(@PathVariable("id") Long id) {
        adoptionService.deleteAdoptionById(id);
        return "redirect:/applications";
    }
}