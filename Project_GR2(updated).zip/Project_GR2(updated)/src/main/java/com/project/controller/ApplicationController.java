package com.project.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.project.dto.ApplicationInput;
import com.project.model.Application;
import com.project.service.AdoptionService;
import com.project.service.PetService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Controller
public class ApplicationController {

    private final ObjectMapper mapper= new ObjectMapper();

    final AdoptionService adoptionService ;

    final PetService petService;

    public ApplicationController(AdoptionService adoptionService, PetService petService) {
        this.adoptionService = adoptionService;
        this.petService = petService;
    }

    @GetMapping("/applications")
    public String showApplications(Model model) {
        List<Application> applicationList = adoptionService.getAllApplications();
        model.addAttribute("applications", applicationList);
        return "listApplications";
    }

    @GetMapping("/adoptionForm/{id}")
    public String showAdoptionForm(@PathVariable Long id, Model model) {
        ApplicationInput application = new ApplicationInput();
        Long currentPetId = petService.getPetById(id).get().getId();
        application.setPetID(currentPetId);
        model.addAttribute("application", application);
        return "addApplication";
    }

    @PostMapping("/addAdoption")
    public String saveApplication(@Valid @ModelAttribute("application") ApplicationInput saveApplication, BindingResult result) {

        if (result.hasErrors()){
            //I need to stay in the current page !!!!
            return "addApplication";
        }
        Application appl = mapper.convertValue(saveApplication, Application.class);
        adoptionService.saveApplicationToDB(appl);
        return "redirect:/applications";
    }

    @GetMapping("/deleteApplication/{id}")
    public String deleteApplication(@PathVariable("id") Long id) {
        adoptionService.deleteAdoptionById(id);
        return "redirect:/applications";
    }
}