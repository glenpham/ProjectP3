package com.project.model;

import lombok.*;

@AllArgsConstructor
@Builder
@NoArgsConstructor
@Getter
@Setter
public class Address {

    private int id;

    private int doorNum;

    private String street;

    private String city;

    private String state;

    private String country;
}