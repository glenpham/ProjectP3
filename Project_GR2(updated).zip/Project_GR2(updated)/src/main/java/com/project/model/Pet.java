package com.project.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.util.List;

@Entity
@Getter
@Setter
@Table(name = "pets")
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class Pet {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private String type;

	private String gender;

	private String breed;

	private int age;

	private String name;

	private int price;

	@Lob
	@Column(columnDefinition = "MEDIUMBLOB")
	private String image;

	private String description;
}