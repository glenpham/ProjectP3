package com.project.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.util.List;

@Entity
@Getter
@Setter
@Table(name = "pets")
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class Pet {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@NotEmpty
	private String type;

	@NotEmpty
	private String gender;

	@NotEmpty
	private String breed;

	@NotNull
	private int age;

	@NotEmpty
	private String name;

	@NotNull
	private int price;

	@Lob
	@Column(columnDefinition = "MEDIUMBLOB")
	private String image;

	@NotEmpty
	@Size(max = 250)
	private String description;
}