package com.project.service;

import java.io.IOException;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import com.project.dto.PetInput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.project.repository.PetRepository;
import com.project.model.Pet;

@Service
public class PetService {
    @Autowired
    private PetRepository petRepository;

    public void savePetToDB(PetInput petInput) {
        Pet pet = new Pet();

        String fileName = StringUtils.cleanPath(petInput.getImage().getOriginalFilename());
        if (fileName.contains("..")) {
            System.out.println("not a a valid file");
        }
        try {
            pet.setImage(Base64.getEncoder().encodeToString(petInput.getImage().getBytes()));
        } catch (IOException e) {
            e.printStackTrace();
        }

        pet.setType(petInput.getType());
        pet.setGender(petInput.getGender());
        pet.setBreed(petInput.getBreed());
        pet.setAge(petInput.getAge());
        pet.setName(petInput.getName());
        pet.setPrice(petInput.getPrice());
        pet.setDescription(petInput.getDescription());
        petRepository.save(pet);
    }

    public List<Pet> getAllPets() {
        return petRepository.findAll();
    }

    public Optional<Pet> getPetById(Long petId){
        return petRepository.findById(petId);
    }

    public void deletePetById(Long id) {
        petRepository.deleteById(id);
    }

    public void changePetName(Long id, String name) {
        Pet p = petRepository.findById(id).get();
        p.setName(name);
        petRepository.save(p);
    }

    public void changePetBreed(Long id, String breed) {
        Pet p = petRepository.findById(id).get();
        p.setBreed(breed);
        petRepository.save(p);
    }

    public void changePetGender(Long id, String gender) {
        Pet p = petRepository.findById(id).get();
        p.setGender(gender);
        petRepository.save(p);
    }

    public void changePetAge(Long id, int age) {
        Pet p = petRepository.findById(id).get();
        p.setAge(age);
        petRepository.save(p);
    }

    public void changePetDescription(Long id, String description) {
        Pet p = petRepository.findById(id).get();
        p.setDescription(description);
        petRepository.save(p);
    }

    public void changePetPrice(Long id, int price) {
        Pet p = petRepository.findById(id).get();
        p.setPrice(price);
        petRepository.save(p);
    }
}