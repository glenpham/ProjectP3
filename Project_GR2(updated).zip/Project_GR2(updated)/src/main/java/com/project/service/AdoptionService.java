package com.project.service;

import com.project.model.Application;
import com.project.repository.AdoptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AdoptionService {

    @Autowired
    private AdoptionRepository adoptionRepository;

    public void saveApplicationToDB(Application application) {
        adoptionRepository.save(application);
    }

    public List<Application> getAllApplications() {
        return adoptionRepository.findAll();
    }

    public void deleteAdoptionById(Long id) {
        adoptionRepository.deleteById(id);
    }

}