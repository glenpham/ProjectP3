package com.project.dto;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.*;

import static com.project.constant.ErrorMessage.*;
import static com.project.constant.ErrorMessage.PHONE_SIZE_ERROR_MESSAGE;

@AllArgsConstructor
@Builder
@NoArgsConstructor
@Getter
@Setter
public class ApplicationInput {

    private Long id;

    private Long petID;

    @NotEmpty(message = NAME_IS_REQUIRED_ERROR_MESSAGE)
    @Size(min=2, message = NAME_SIZE_ERROR_MESSAGE)
    private String fname;

    @NotEmpty(message = NAME_IS_REQUIRED_ERROR_MESSAGE)
    @Size(min=2, message = NAME_SIZE_ERROR_MESSAGE)
    private String lname;

    @NotEmpty(message = EMAIL_IS_REQUIRED_ERROR_MESSAGE)
    @Pattern(regexp = "^[a-zA-Z\\d+_.-]+@[a-zA-Z\\d.-]+$", message = "please provide a valid email")
    private String email;

    @NotEmpty(message = ADDRESS_IS_REQUIRED_ERROR_MESSAGE)
    private String address;

    @Pattern(regexp = "^[0-9]*$", message = "please provide a valid phone number")
    @NotEmpty(message = PHONE_IS_REQUIRED_ERROR_MESSAGE)
    @Size(min=10, message = PHONE_SIZE_ERROR_MESSAGE)
    private String phoneNum;
}
