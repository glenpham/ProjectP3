package com.project.dto;

import lombok.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import static com.project.constant.ErrorMessage.NAME_IS_REQUIRED_ERROR_MESSAGE;
import static com.project.constant.ErrorMessage.NAME_SIZE_ERROR_MESSAGE;

@AllArgsConstructor
@Builder
@NoArgsConstructor
@Getter
@Setter
public class PetInput {

    private Long id;

    @NotEmpty(message = "please provide type")
    private String type;

    @NotEmpty(message = "please provide gender")
    private String gender;

    @NotEmpty(message = "please provide breed")
    private String breed;

    @NotNull(message = "please provide age")
    @Min(value = 1, message = "age must be 1 or higher")
    private int age;

    @NotEmpty(message = NAME_IS_REQUIRED_ERROR_MESSAGE)
    @Size(min=2, message = NAME_SIZE_ERROR_MESSAGE)
    private String name;

    @NotNull(message = "please provide price")
    @Min(value = 1, message = "price must be 1 or higher")
    private int price;

    @NotNull(message = "Enter something")
    private MultipartFile image;

    @NotEmpty(message = "Please enter a description")
    @Size(max = 250)
    private String description;
}
